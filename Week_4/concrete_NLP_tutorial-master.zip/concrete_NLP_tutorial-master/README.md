# NLP Workshop for ODSC 2017
Feel free to follow along in this notebook, or download it and run it yourself. Instructions below.

# Installation instructions

#### clone the repository

#### download pretrained google word vectors
http://mccormickml.com/2016/04/12/googles-pretrained-word2vec-model-in-python/

#### download pretrained char-rnn for Yelp
`curl -O https://s3.amazonaws.com/yelp-weights-files/Sep-26-all-00-0.7280.hdf5`

rename the file to 'pretrained-yelp.hdf5'
